package com.example.kosci;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Random losowanie = new Random();
    int wynikGry = 0;

    ImageView[] obrazyKosci = new ImageView[5];
    int[] grafikiKosci = {
            R.drawable.k1,
            R.drawable.k2,
            R.drawable.k3,
            R.drawable.k4,
            R.drawable.k5,
            R.drawable.k6
    };

    TextView etykietaWynikLosowania;
    TextView etykietaWynikGry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        obrazyKosci[0] = findViewById(R.id.kosc1);
        obrazyKosci[1] = findViewById(R.id.kosc2);
        obrazyKosci[2] = findViewById(R.id.kosc3);
        obrazyKosci[3] = findViewById(R.id.kosc4);
        obrazyKosci[4] = findViewById(R.id.kosc5);

        etykietaWynikLosowania = findViewById(R.id.etykietaWynikLosowania);
        etykietaWynikGry = findViewById(R.id.etykietaWynikGry);

        Button przyciskRzuc = findViewById(R.id.przyciskRzuc);
        Button przyciskResetuj = findViewById(R.id.przyciskResetuj);

        przyciskRzuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rzucKostkami();
            }
        });

        przyciskResetuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetujWynik();
            }
        });
    }

    int[] losujOczka(int liczbaKostek) {
        int[] wyniki = new int[liczbaKostek];

        for (int i = 0; i < liczbaKostek; i++) {
            wyniki[i] = losowanie.nextInt(6) + 1;
        }

        return wyniki;
    }

    int liczPunkty(int[] wyniki) {
        int punkty = 0;

        for (int oczka = 1; oczka <= 6; oczka++) {
            int ileRazy = 0;

            for (int wynik : wyniki) {
                if (wynik == oczka) {
                    ileRazy++;
                }
            }

            if (ileRazy >= 2) {
                punkty = punkty + oczka * ileRazy;
            }
        }

        return punkty;
    }

    void rzucKostkami() {
        int[] wyniki = losujOczka(5);

        for (int i = 0; i < 5; i++) {
            obrazyKosci[i].setImageResource(grafikiKosci[wyniki[i] - 1]);
        }

        int wynikLosowania = liczPunkty(wyniki);
        wynikGry = wynikGry + wynikLosowania;

        etykietaWynikLosowania.setText("Wynik tego losowania: " + wynikLosowania);
        etykietaWynikGry.setText("Wynik gry: " + wynikGry);
    }

    void resetujWynik() {
        for (int i = 0; i < 5; i++) {
            obrazyKosci[i].setImageResource(R.drawable.question);
        }

        wynikGry = 0;
        etykietaWynikLosowania.setText("Wynik tego losowania: 0");
        etykietaWynikGry.setText("Wynik gry: 0");
    }
}