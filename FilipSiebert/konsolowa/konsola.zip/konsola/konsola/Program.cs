﻿using System;
using System.Text;

class Program
{
    /************************************************
     nazwa: RzucKostkami
     opis: losuje liczby od 1 do 6, po jednej dla każdej kostki
     parametry: liczbaKostek - ile kostek ma być rzuconych
     zwracany typ i opis: int[] - tablica z wylosowanymi oczkami
     autor: 000000000
    ************************************************/
    static int[] RzucKostkami(int liczbaKostek)
    {
        Random losowanie = new Random();
        int[] wyniki = new int[liczbaKostek];

        for (int i = 0; i < liczbaKostek; i++)
        {
            wyniki[i] = losowanie.Next(1, 7);
        }

        return wyniki;
    }

    /************************************************
     nazwa: LiczPunkty
     opis: sumuje oczka, które wypadły co najmniej dwa razy
     parametry: wyniki - tablica z wylosowanymi oczkami
     zwracany typ i opis: int - suma uzyskanych punktów
     autor: 000000000
    ************************************************/
    static int LiczPunkty(int[] wyniki)
    {
        int punkty = 0;

        for (int oczka = 1; oczka <= 6; oczka++)
        {
            int ileRazy = 0;

            foreach (int wynik in wyniki)
            {
                if (wynik == oczka)
                {
                    ileRazy++;
                }
            }

            if (ileRazy >= 2)
            {
                punkty = punkty + oczka * ileRazy;
            }
        }

        return punkty;
    }

    static int PobierzLiczbeKostek()
    {
        int liczbaKostek = 0;

        while (liczbaKostek < 3 || liczbaKostek > 10)
        {
            Console.WriteLine("Ile kostek chcesz rzucić?(3 - 10)");
            string tekst = Console.ReadLine();

            if (!int.TryParse(tekst, out liczbaKostek))
            {
                liczbaKostek = 0;
            }
        }

        return liczbaKostek;
    }

    static bool CzyGracDalej()
    {
        string odpowiedz = "";

        while (odpowiedz != "t" && odpowiedz != "n")
        {
            Console.WriteLine("Jeszcze raz? (t/n)");
            odpowiedz = Console.ReadLine();
        }

        return odpowiedz == "t";
    }

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        int liczbaKostek = PobierzLiczbeKostek();
        bool graDalej = true;

        while (graDalej)
        {
            int[] wyniki = RzucKostkami(liczbaKostek);

            for (int i = 0; i < wyniki.Length; i++)
            {
                Console.WriteLine("Kostka " + (i + 1) + ": " + wyniki[i]);
            }

            int punkty = LiczPunkty(wyniki);
            Console.WriteLine("Liczba uzyskanych punktów: " + punkty);

            graDalej = CzyGracDalej();
        }
    }
}